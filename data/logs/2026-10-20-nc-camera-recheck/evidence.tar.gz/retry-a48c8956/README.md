# 再次重启后独占拍照复查：a48c8956

- 日期/执行人：2026-10-20，NC主控；Pi日历Oct06，仅作原始输出。
- 版本：dev/riscv@5f8abe2 + 现有未提交SSH助手；本轮未修改程序/配置/RTL、不commit。
- 命令：0001..0003.request.json；用户完成SSH认证后串行执行，完整输出与退出码同号response.json。
- 结果：IMX708重新枚举成功；停服务后无rpicam进程，fuser退出1确认无人占用，EXCLUSIVE_CHECK_OK；独立nopreview拍照仍超时exit124、NO_JPEG。
- 产物：6份原始请求/响应；本轮Pi boot_id=a48c8956-92a9-4a9e-beb4-0ec6827af9d4；拍照日志保留在Pi项目data/logs/2026-10-20-camera-retry-a48c8956/probe.log，全文已在0002.response.json保存。
- 边界：排除本次测试时预览服务/其他进程占用，未证明相机硬件正常，也未确定排线损坏。内核过滤日志未见用户提到的Failed to start media pipeline: -22。

服务起初PID665 active/running/NRestarts=0，却持续frontend timeout。停服务后模式枚举恢复有效尺寸/裁剪，独立配置仍未取到图像；media-ctl中IMX708→unicam-image链存在且enabled。get_throttled=0x0。
结束状态：pi-camera-preview.service inactive/dead、MainPID=0，无rpicam进程、无/dev/video0占用；仅stop当前服务，没有disable其开机启用。SSH暂保留供用户继续，助手最多1小时，未设置自动监控。
