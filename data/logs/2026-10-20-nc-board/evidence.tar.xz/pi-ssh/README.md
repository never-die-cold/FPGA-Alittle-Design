# Pi SSH 原始命令与响应

- 日期：2026-10-20（电脑）；Pi日历Oct06，原始输出保留。
- 版本：主控dev/riscv@5f8abe2 + 本轮未提交SSH助手；运行源码SHA见父目录ssh-session-running-source-sha.txt。
- 命令：0001..0007.request.json；用户本人本机getpass认证，没有存储密码/新增远端登录key。
- 结果：对应response含真实exit_code与completion_confirmed；0004拍照exit124且NO_JPEG，0007留场检查exit2（活跃相机进程），其余诊断退出0不代表相机成功。
- 产物：14份原始请求/响应与final-state.json（connected=false）；完整独立拍照日志见0007，欠压标记见0003。
- 边界：直连绕过PYNQ仍无相机图像；最后服务active/running/enabled，PID2575；主控未再操作，不能声称结束时已停止相机。缺少换线/换相机交叉验证，不断言具体损坏件。

助手源码后续补充SSH无退出状态(-1)必须标未确认，仓库test_nc_ssh_session.py负例通过；该边界未在本轮真实SSH触发。代码未提交。
