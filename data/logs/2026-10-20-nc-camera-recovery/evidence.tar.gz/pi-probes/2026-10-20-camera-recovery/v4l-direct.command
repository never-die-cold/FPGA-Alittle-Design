v4l2-ctl -d /dev/video0 --stream-mmap=3 --stream-count=2 --stream-poll --stream-to=/home/edgesight/FPGA-Alittle-Design/data/logs/2026-10-20-camera-recovery/v4l-direct.raw 
