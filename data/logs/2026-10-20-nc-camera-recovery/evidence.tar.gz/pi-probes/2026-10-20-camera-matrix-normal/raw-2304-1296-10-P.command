rpicam-raw --nopreview --mode 2304:1296:10:P --framerate 2 --timeout 1000 --output /home/edgesight/FPGA-Alittle-Design/data/logs/2026-10-20-camera-matrix-normal/raw-2304-1296-10-P.raw 
